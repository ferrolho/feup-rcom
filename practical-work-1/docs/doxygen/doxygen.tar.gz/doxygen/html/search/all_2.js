var searchData=
[
  ['c_5fdisc',['C_DISC',['../DataLink_8h.html#ad472b45abdeb8adcb4043ef419b3fff0a45da09de259fcfe0a2ceedfc14656a82',1,'DataLink.h']]],
  ['c_5frcv',['C_RCV',['../DataLink_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a036dfe132c93a0ee9e92a199d61f0738',1,'DataLink.h']]],
  ['c_5frej',['C_REJ',['../DataLink_8h.html#ad472b45abdeb8adcb4043ef419b3fff0afa52405512ebe2d0069aaa60162f7c4e',1,'DataLink.h']]],
  ['c_5frr',['C_RR',['../DataLink_8h.html#ad472b45abdeb8adcb4043ef419b3fff0ae57eb4cd062488e3d7bc8cd86797b586',1,'DataLink.h']]],
  ['c_5fset',['C_SET',['../DataLink_8h.html#ad472b45abdeb8adcb4043ef419b3fff0ae336acbacbc07a4378be0c6800eff093',1,'DataLink.h']]],
  ['c_5fua',['C_UA',['../DataLink_8h.html#ad472b45abdeb8adcb4043ef419b3fff0a2cf23588b56ff683779b146b0f12e3a2',1,'DataLink.h']]],
  ['cleanbuf',['cleanBuf',['../DataLink_8c.html#a08b7a2e8bb868ca529122802c4675c3a',1,'cleanBuf(unsigned char *buf, ui bufSize):&#160;DataLink.c'],['../DataLink_8h.html#a08b7a2e8bb868ca529122802c4675c3a',1,'cleanBuf(unsigned char *buf, ui bufSize):&#160;DataLink.c']]],
  ['clearinputbuffer',['clearInputBuffer',['../CLI_8c.html#a22d7c3e857afba4903a76181f91ea9fb',1,'clearInputBuffer():&#160;CLI.c'],['../CLI_8h.html#a22d7c3e857afba4903a76181f91ea9fb',1,'clearInputBuffer():&#160;CLI.c']]],
  ['cli_2ec',['CLI.c',['../CLI_8c.html',1,'']]],
  ['cli_2eh',['CLI.h',['../CLI_8h.html',1,'']]],
  ['closeserialport',['closeSerialPort',['../DataLink_8c.html#a0403c28eb847ace30868ab90551a0230',1,'closeSerialPort():&#160;DataLink.c'],['../DataLink_8h.html#a0403c28eb847ace30868ab90551a0230',1,'closeSerialPort():&#160;DataLink.c']]],
  ['command',['command',['../structMessage.html#a4c1dcef1a82551c0803afbba8159382e',1,'Message::command()'],['../DataLink_8h.html#ac6606ebe91c8ac66a2c314c79f5ab013ae680fa7eb860abe7832f792cc18a44b4',1,'COMMAND():&#160;DataLink.h'],['../DataLink_8h.html#a2afce0a47a93eee73a314d53e4890153',1,'Command():&#160;DataLink.h']]],
  ['command_5fsize',['COMMAND_SIZE',['../DataLink_8h.html#a84a810435e7fe57556de76b6f8f4fd3ba66e5ef807097fb6ac27818114deae1ce',1,'DataLink.h']]],
  ['controlfield',['ControlField',['../DataLink_8h.html#ad472b45abdeb8adcb4043ef419b3fff0',1,'DataLink.h']]],
  ['controlpackagetype',['ControlPackageType',['../ControlPackageType_8h.html#aa06cd50222db3fb9cd5d1a88912088f7',1,'ControlPackageType.h']]],
  ['controlpackagetype_2eh',['ControlPackageType.h',['../ControlPackageType_8h.html',1,'']]],
  ['createcommand',['createCommand',['../DataLink_8c.html#a9e9eadf71a24a14e7c6b25f8b095dbe4',1,'createCommand(ControlField C):&#160;DataLink.c'],['../DataLink_8h.html#a9e9eadf71a24a14e7c6b25f8b095dbe4',1,'createCommand(ControlField C):&#160;DataLink.c']]],
  ['createmessage',['createMessage',['../DataLink_8c.html#ac77140eba97919343f3370bdaaf31b39',1,'createMessage(const unsigned char *message, ui size):&#160;DataLink.c'],['../DataLink_8h.html#aa2a03c611f0a3cd6076a70022974d33f',1,'createMessage(const unsigned char *buf, ui bufSize):&#160;DataLink.c']]],
  ['ctrl_5fpkg_5fdata',['CTRL_PKG_DATA',['../ControlPackageType_8h.html#aa06cd50222db3fb9cd5d1a88912088f7a9aa69763123f5ab3d0eaade0337f8440',1,'ControlPackageType.h']]],
  ['ctrl_5fpkg_5fend',['CTRL_PKG_END',['../ControlPackageType_8h.html#aa06cd50222db3fb9cd5d1a88912088f7ab0d866e8ba1ff997e18d2169eeae72f7',1,'ControlPackageType.h']]],
  ['ctrl_5fpkg_5fstart',['CTRL_PKG_START',['../ControlPackageType_8h.html#aa06cd50222db3fb9cd5d1a88912088f7a1a930be21f0fb2b8da58ed7cc2b4b4b5',1,'ControlPackageType.h']]]
];
