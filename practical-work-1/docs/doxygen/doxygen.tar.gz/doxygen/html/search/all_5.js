var searchData=
[
  ['false',['FALSE',['../Utilities_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'Utilities.h']]],
  ['fd',['fd',['../structApplicationLayer.html#a27603936f9300b3aea40aedfb65b069d',1,'ApplicationLayer']]],
  ['filename',['fileName',['../structApplicationLayer.html#a0fbe92886a8ebe258f22052bff2d4a9a',1,'ApplicationLayer']]],
  ['flag',['FLAG',['../DataLink_8c.html#ad555dbfb47368c828d839ccc6e3d7e89',1,'DataLink.c']]],
  ['flag_5frcv',['FLAG_RCV',['../DataLink_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8ae750604506ada515654b21b3f8641bbf',1,'DataLink.h']]],
  ['frame',['frame',['../structLinkLayer.html#a9cdc884a9d83cc643bd8d9ff6d50c6e9',1,'LinkLayer']]]
];
