var searchData=
[
  ['linklayer',['LinkLayer',['../structLinkLayer.html',1,'']]],
  ['ll',['ll',['../DataLink_8c.html#a391b7335768e2630c1fa311b696efe5e',1,'ll():&#160;DataLink.c'],['../DataLink_8h.html#a391b7335768e2630c1fa311b696efe5e',1,'ll():&#160;DataLink.c']]],
  ['llclose',['llclose',['../DataLink_8c.html#a5796ccff54dd4a61ec471010d1838cda',1,'llclose(int fd, ConnnectionMode mode):&#160;DataLink.c'],['../DataLink_8h.html#a5796ccff54dd4a61ec471010d1838cda',1,'llclose(int fd, ConnnectionMode mode):&#160;DataLink.c']]],
  ['llopen',['llopen',['../DataLink_8c.html#ae95b679b4b9930c7c2eb5bb1339b5f0a',1,'llopen(ConnnectionMode mode):&#160;DataLink.c'],['../DataLink_8h.html#ae95b679b4b9930c7c2eb5bb1339b5f0a',1,'llopen(ConnnectionMode mode):&#160;DataLink.c']]],
  ['llread',['llread',['../DataLink_8c.html#a5a603997c23de36c383f19dc00e81743',1,'llread(int fd, unsigned char **message):&#160;DataLink.c'],['../DataLink_8h.html#a5a603997c23de36c383f19dc00e81743',1,'llread(int fd, unsigned char **message):&#160;DataLink.c']]],
  ['llwrite',['llwrite',['../DataLink_8c.html#a79e461b24752ccc70c85ec7da101e3e3',1,'llwrite(int fd, const unsigned char *buf, ui bufSize):&#160;DataLink.c'],['../DataLink_8h.html#a79e461b24752ccc70c85ec7da101e3e3',1,'llwrite(int fd, const unsigned char *buf, ui bufSize):&#160;DataLink.c']]]
];
