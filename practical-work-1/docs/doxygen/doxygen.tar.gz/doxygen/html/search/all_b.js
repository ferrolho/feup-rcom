var searchData=
[
  ['openserialport',['openSerialPort',['../DataLink_8c.html#a8172ce6e297f1567e45425a50f5d5ec2',1,'openSerialPort(const char *port):&#160;DataLink.c'],['../DataLink_8h.html#a8172ce6e297f1567e45425a50f5d5ec2',1,'openSerialPort(const char *port):&#160;DataLink.c']]]
];
