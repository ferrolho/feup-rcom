var searchData=
[
  ['receivecontrolpackage',['receiveControlPackage',['../Aplication_8c.html#a9726fe48658421881a45e41c34df46c6',1,'receiveControlPackage(int fd, int *controlPackageType, int *fileLength, char **fileName):&#160;Aplication.c'],['../Aplication_8h.html#a5904205666df376049c4b964eccaec6d',1,'receiveControlPackage(int fd, int *ctrl, int *fileLength, char **fileName):&#160;Aplication.c']]],
  ['receivedatapackage',['receiveDataPackage',['../Aplication_8c.html#aba54d26c3685755062ca8f4484e83c26',1,'receiveDataPackage(int fd, int *N, char **buf, int *length):&#160;Aplication.c'],['../Aplication_8h.html#aba54d26c3685755062ca8f4484e83c26',1,'receiveDataPackage(int fd, int *N, char **buf, int *length):&#160;Aplication.c']]],
  ['receivedmessages',['receivedMessages',['../structStatistics.html#ad524b723b1b2ac8ad1fc9760a2243cdb',1,'Statistics']]],
  ['receivefile',['receiveFile',['../Aplication_8c.html#a672b1d6bcaa2e97f35edf7665b10c71b',1,'receiveFile():&#160;Aplication.c'],['../Aplication_8h.html#a672b1d6bcaa2e97f35edf7665b10c71b',1,'receiveFile():&#160;Aplication.c']]],
  ['receivemessage',['receiveMessage',['../DataLink_8c.html#ae104dc8aa78bee8583880ab6a5dd0622',1,'receiveMessage(int fd):&#160;DataLink.c'],['../DataLink_8h.html#ae104dc8aa78bee8583880ab6a5dd0622',1,'receiveMessage(int fd):&#160;DataLink.c']]],
  ['rej',['REJ',['../DataLink_8h.html#a2afce0a47a93eee73a314d53e4890153a74ab94ba369bf3c46097bc3d0ba46688',1,'DataLink.h']]],
  ['rr',['RR',['../DataLink_8h.html#a2afce0a47a93eee73a314d53e4890153aea4586c054afe1678864fa75dfb1787d',1,'DataLink.h']]]
];
