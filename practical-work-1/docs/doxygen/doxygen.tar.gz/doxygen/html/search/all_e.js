var searchData=
[
  ['savecurrentportsettingsandsetnewtermios',['saveCurrentPortSettingsAndSetNewTermios',['../DataLink_8c.html#a0a0b08bf7e5eb5e63d60f78038103420',1,'saveCurrentPortSettingsAndSetNewTermios():&#160;DataLink.c'],['../DataLink_8h.html#a0a0b08bf7e5eb5e63d60f78038103420',1,'saveCurrentPortSettingsAndSetNewTermios():&#160;DataLink.c']]],
  ['savecurrenttermiossettings',['saveCurrentTermiosSettings',['../DataLink_8c.html#af30483a28563a2783359acaf94d693b5',1,'saveCurrentTermiosSettings():&#160;DataLink.c'],['../DataLink_8h.html#af30483a28563a2783359acaf94d693b5',1,'saveCurrentTermiosSettings():&#160;DataLink.c']]],
  ['sendcommand',['sendCommand',['../DataLink_8c.html#a8f7b3b594fd3cfdd34c543340a1a4d6a',1,'sendCommand(int fd, Command command):&#160;DataLink.c'],['../DataLink_8h.html#a8f7b3b594fd3cfdd34c543340a1a4d6a',1,'sendCommand(int fd, Command command):&#160;DataLink.c']]],
  ['sendcontrolpackage',['sendControlPackage',['../Aplication_8c.html#a2f2eb44ecd2adcf86f887d0403f0f383',1,'sendControlPackage(int fd, int C, char *fileSize, char *fileName):&#160;Aplication.c'],['../Aplication_8h.html#a2f2eb44ecd2adcf86f887d0403f0f383',1,'sendControlPackage(int fd, int C, char *fileSize, char *fileName):&#160;Aplication.c']]],
  ['senddatapackage',['sendDataPackage',['../Aplication_8c.html#a2e05c353561d2232f5196b87639610e0',1,'sendDataPackage(int fd, int N, const char *buffer, int length):&#160;Aplication.c'],['../Aplication_8h.html#aa37d73d0e09d28482d8b9c4a2dfb88f0',1,'sendDataPackage(int fd, int N, const char *buf, int length):&#160;Aplication.c']]],
  ['sendfile',['sendFile',['../Aplication_8c.html#acd6f1b444cf42eac288c3f4ae1e2eb0a',1,'sendFile():&#160;Aplication.c'],['../Aplication_8h.html#acd6f1b444cf42eac288c3f4ae1e2eb0a',1,'sendFile():&#160;Aplication.c']]],
  ['sendmessage',['sendMessage',['../DataLink_8c.html#a36ab789a49aec5abd1427b2b0425dab2',1,'sendMessage(int fd, const unsigned char *message, ui messageSize):&#160;DataLink.c'],['../DataLink_8h.html#a55440c0d7af0d104778159feb8002745',1,'sendMessage(int fd, const unsigned char *buf, ui bufSize):&#160;DataLink.c']]],
  ['sentmessages',['sentMessages',['../structStatistics.html#aebc3551bed9cc7d4e29c586268e7146c',1,'Statistics']]],
  ['set',['SET',['../DataLink_8h.html#a2afce0a47a93eee73a314d53e4890153ab44c8101cc294c074709ec1b14211792',1,'DataLink.h']]],
  ['setalarm',['setAlarm',['../Alarm_8c.html#a75e98b9730357038111037edda8339df',1,'setAlarm():&#160;Alarm.c'],['../Alarm_8h.html#a75e98b9730357038111037edda8339df',1,'setAlarm():&#160;Alarm.c']]],
  ['setnewtermios',['setNewTermios',['../DataLink_8c.html#a8995794913515a478e3d00503dbc393a',1,'setNewTermios():&#160;DataLink.c'],['../DataLink_8h.html#a8995794913515a478e3d00503dbc393a',1,'setNewTermios():&#160;DataLink.c']]],
  ['start',['START',['../DataLink_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a13d000b4d7dc70d90239b7430d1eb6b2',1,'DataLink.h']]],
  ['startcli',['startCLI',['../CLI_8c.html#a7a78a0e4c77c9795d24028779ea4142b',1,'startCLI():&#160;CLI.c'],['../CLI_8h.html#a7a78a0e4c77c9795d24028779ea4142b',1,'startCLI():&#160;CLI.c']]],
  ['startconnection',['startConnection',['../Aplication_8c.html#a3622090a7ff391221a74cad6493bbca9',1,'startConnection():&#160;Aplication.c'],['../Aplication_8h.html#a3622090a7ff391221a74cad6493bbca9',1,'startConnection():&#160;Aplication.c']]],
  ['state',['State',['../DataLink_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8',1,'DataLink.h']]],
  ['statistics',['Statistics',['../structStatistics.html',1,'']]],
  ['stats',['stats',['../structLinkLayer.html#ad4f9744f71c18d5e8c82e4ed102df07f',1,'LinkLayer']]],
  ['stop',['STOP',['../DataLink_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a679ee5320d66c8322e310daeb2ee99b8',1,'DataLink.h']]],
  ['stopalarm',['stopAlarm',['../Alarm_8c.html#a7ae58fc4d576671de97e4eab7d92d8ce',1,'stopAlarm():&#160;Alarm.c'],['../Alarm_8h.html#a7ae58fc4d576671de97e4eab7d92d8ce',1,'stopAlarm():&#160;Alarm.c']]],
  ['stuff',['stuff',['../DataLink_8c.html#a7f9762bc2b4d4f481f6278ae7a76da52',1,'stuff(unsigned char **buf, ui bufSize):&#160;DataLink.c'],['../DataLink_8h.html#a7f9762bc2b4d4f481f6278ae7a76da52',1,'stuff(unsigned char **buf, ui bufSize):&#160;DataLink.c']]]
];
