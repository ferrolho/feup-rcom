var searchData=
[
  ['message',['Message',['../structMessage.html',1,'']]]
];
