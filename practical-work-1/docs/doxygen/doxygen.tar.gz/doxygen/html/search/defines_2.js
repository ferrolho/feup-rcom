var searchData=
[
  ['max_5fsize',['MAX_SIZE',['../Utilities_8h.html#a0592dba56693fad79136250c11e5a7fe',1,'Utilities.h']]]
];
