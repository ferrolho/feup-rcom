var searchData=
[
  ['data',['DATA',['../DataLink_8h.html#ac6606ebe91c8ac66a2c314c79f5ab013a9d7d6f31868d66330397c967c4afd2d2',1,'DataLink.h']]],
  ['disc',['DISC',['../DataLink_8h.html#a2afce0a47a93eee73a314d53e4890153a8f7f92368702925bce9365ec82c7844c',1,'DataLink.h']]]
];
