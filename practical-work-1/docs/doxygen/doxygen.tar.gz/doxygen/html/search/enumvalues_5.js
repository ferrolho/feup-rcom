var searchData=
[
  ['input_5foutput_5ferror',['INPUT_OUTPUT_ERROR',['../DataLink_8h.html#a9374dcf03c1691f812daf280dd37523fa8efb63805f335b88020f52013c707011',1,'DataLink.h']]],
  ['invalid',['INVALID',['../DataLink_8h.html#ac6606ebe91c8ac66a2c314c79f5ab013aef2863a469df3ea6871d640e3669a2f2',1,'DataLink.h']]]
];
