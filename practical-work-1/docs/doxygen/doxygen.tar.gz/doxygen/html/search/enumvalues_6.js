var searchData=
[
  ['message_5fsize',['MESSAGE_SIZE',['../DataLink_8h.html#a84a810435e7fe57556de76b6f8f4fd3bab0c9fe82510fc74a327dadb270fce0a4',1,'DataLink.h']]]
];
