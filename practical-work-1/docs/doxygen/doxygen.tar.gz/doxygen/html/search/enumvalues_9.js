var searchData=
[
  ['set',['SET',['../DataLink_8h.html#a2afce0a47a93eee73a314d53e4890153ab44c8101cc294c074709ec1b14211792',1,'DataLink.h']]],
  ['start',['START',['../DataLink_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a13d000b4d7dc70d90239b7430d1eb6b2',1,'DataLink.h']]],
  ['stop',['STOP',['../DataLink_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a679ee5320d66c8322e310daeb2ee99b8',1,'DataLink.h']]]
];
