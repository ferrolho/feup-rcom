var searchData=
[
  ['cleanbuf',['cleanBuf',['../DataLink_8c.html#a08b7a2e8bb868ca529122802c4675c3a',1,'cleanBuf(unsigned char *buf, ui bufSize):&#160;DataLink.c'],['../DataLink_8h.html#a08b7a2e8bb868ca529122802c4675c3a',1,'cleanBuf(unsigned char *buf, ui bufSize):&#160;DataLink.c']]],
  ['clearinputbuffer',['clearInputBuffer',['../CLI_8c.html#a22d7c3e857afba4903a76181f91ea9fb',1,'clearInputBuffer():&#160;CLI.c'],['../CLI_8h.html#a22d7c3e857afba4903a76181f91ea9fb',1,'clearInputBuffer():&#160;CLI.c']]],
  ['closeserialport',['closeSerialPort',['../DataLink_8c.html#a0403c28eb847ace30868ab90551a0230',1,'closeSerialPort():&#160;DataLink.c'],['../DataLink_8h.html#a0403c28eb847ace30868ab90551a0230',1,'closeSerialPort():&#160;DataLink.c']]],
  ['createcommand',['createCommand',['../DataLink_8c.html#a9e9eadf71a24a14e7c6b25f8b095dbe4',1,'createCommand(ControlField C):&#160;DataLink.c'],['../DataLink_8h.html#a9e9eadf71a24a14e7c6b25f8b095dbe4',1,'createCommand(ControlField C):&#160;DataLink.c']]],
  ['createmessage',['createMessage',['../DataLink_8c.html#ac77140eba97919343f3370bdaaf31b39',1,'createMessage(const unsigned char *message, ui size):&#160;DataLink.c'],['../DataLink_8h.html#aa2a03c611f0a3cd6076a70022974d33f',1,'createMessage(const unsigned char *buf, ui bufSize):&#160;DataLink.c']]]
];
