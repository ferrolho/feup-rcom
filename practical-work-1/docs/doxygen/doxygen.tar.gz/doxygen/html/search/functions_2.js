var searchData=
[
  ['destuff',['destuff',['../DataLink_8c.html#a770b135a5b49e5b597a541dfab1f52ef',1,'destuff(unsigned char **buf, ui bufSize):&#160;DataLink.c'],['../DataLink_8h.html#a770b135a5b49e5b597a541dfab1f52ef',1,'destuff(unsigned char **buf, ui bufSize):&#160;DataLink.c']]]
];
