var searchData=
[
  ['baudrate',['baudRate',['../structLinkLayer.html#ae5172be4ec6f48f65809cf96511fbb30',1,'LinkLayer']]]
];
