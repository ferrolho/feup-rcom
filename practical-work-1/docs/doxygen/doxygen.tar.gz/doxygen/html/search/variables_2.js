var searchData=
[
  ['command',['command',['../structMessage.html#a4c1dcef1a82551c0803afbba8159382e',1,'Message']]]
];
