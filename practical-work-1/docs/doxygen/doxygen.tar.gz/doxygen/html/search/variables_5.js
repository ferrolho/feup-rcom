var searchData=
[
  ['fd',['fd',['../structApplicationLayer.html#a27603936f9300b3aea40aedfb65b069d',1,'ApplicationLayer']]],
  ['filename',['fileName',['../structApplicationLayer.html#a0fbe92886a8ebe258f22052bff2d4a9a',1,'ApplicationLayer']]],
  ['flag',['FLAG',['../DataLink_8c.html#ad555dbfb47368c828d839ccc6e3d7e89',1,'DataLink.c']]],
  ['frame',['frame',['../structLinkLayer.html#a9cdc884a9d83cc643bd8d9ff6d50c6e9',1,'LinkLayer']]]
];
