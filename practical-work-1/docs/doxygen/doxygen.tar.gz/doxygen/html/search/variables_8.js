var searchData=
[
  ['newtio',['newtio',['../structLinkLayer.html#a7bb28307ed7ee2da71c3384b24a68143',1,'LinkLayer']]],
  ['nr',['nr',['../structMessage.html#a2cff73da214793abd5928478fd3473a3',1,'Message']]],
  ['ns',['ns',['../structMessage.html#a20773cbe746bb5bfede35108a9077ed9',1,'Message::ns()'],['../structLinkLayer.html#a130021d65492a79e9dca98509e206203',1,'LinkLayer::ns()']]],
  ['numreceivedrej',['numReceivedREJ',['../structStatistics.html#a485f0746514750a926630d7312617be8',1,'Statistics']]],
  ['numreceivedrr',['numReceivedRR',['../structStatistics.html#ae698b92f0c653805673f01f03990b441',1,'Statistics']]],
  ['numsentrej',['numSentREJ',['../structStatistics.html#ad4b25acbcaf040ae1a9c56c6c1a9c994',1,'Statistics']]],
  ['numsentrr',['numSentRR',['../structStatistics.html#a95b53b46b35a2a40dece472de3ff4b17',1,'Statistics']]],
  ['numtries',['numTries',['../structLinkLayer.html#ad06461dedec69fe6c802f0e29aeb440b',1,'LinkLayer']]]
];
