var searchData=
[
  ['receivedmessages',['receivedMessages',['../structStatistics.html#ad524b723b1b2ac8ad1fc9760a2243cdb',1,'Statistics']]]
];
