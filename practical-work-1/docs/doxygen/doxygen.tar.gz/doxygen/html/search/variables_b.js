var searchData=
[
  ['sentmessages',['sentMessages',['../structStatistics.html#aebc3551bed9cc7d4e29c586268e7146c',1,'Statistics']]],
  ['stats',['stats',['../structLinkLayer.html#ad4f9744f71c18d5e8c82e4ed102df07f',1,'LinkLayer']]]
];
